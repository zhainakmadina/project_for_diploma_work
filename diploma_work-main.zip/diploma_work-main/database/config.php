<?php

const HOST = "localhost";
const USERNAME = "root";
const PASSWORD = "root";
const DB_NAME = "diplom";