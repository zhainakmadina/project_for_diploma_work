<?php 

require $_SERVER["DOCUMENT_ROOT"].'/database/action.php';
$user_id = $_SESSION["user"]["id"];

$urls = Action::list_urls($user_id);

if(mysqli_num_rows($urls) == 0) {
    echo "You don't have any sites entered";
}

?>

<div class="container-table">
    <div class="table">
        <table>
            <thead>
                <tr class="table-head">
                    <th>ID url</th>
                    <th>Url</th>
                    <th>Date added</th>
                    <th>Lightouse result</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($urls as $url) { ?>
                <tr>
                    <td><?php echo $url["id"]; ?></td>
                    <td><a target="_blank" href="<?php echo $url["url"]; ?>"><?php echo $url["url"]; ?></a></td>
                    <td>
                        <?php
                            echo date("d-m-Y H:i:s", strtotime($url["date_add"]));
                        ?>
                    </td>
                    <td><a href="/?page=lh_result&id_url=<?php echo $url["id"]; ?>">View result</a></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>