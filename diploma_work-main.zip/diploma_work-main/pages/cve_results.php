<?php 

require $_SERVER["DOCUMENT_ROOT"].'/database/action.php';

$id_url = $_GET['id_url'];
$cves_encode = mysqli_fetch_assoc(Action::get_cves($id_url));

$cves = json_decode($cves_encode["cve"]);

if(count($cves) == 0) {
    echo "This site don't have cve";
    exit();
}

?>

<div class="container-table">
    <div class="table">
        <table>
            <thead>
                <tr class="table-head">
                    <th>CVE</th>
                    <th>Result</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($cves as $cve) { ?>
                <tr>
                    <td>
                        <?php
                            echo $cve; 
                        ?>
                    </td>
                    <td><a href="?page=cve&cve=<?php echo $cve; ?>">More</a></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>