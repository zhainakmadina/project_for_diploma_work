<?php

?>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
        var data = google.visualization.arrayToDataTable([
            ['Year', 'Sales', 'Expenses'],
            ['2013',  1000,      400],
            ['2014',  1170,      460],
            ['2015',  660,       1120],
            ['2016',  1030,      540]
        ]);

        var options = {
            title: 'Analyze of vulnerabilities',
            hAxis: {title: 'Year',  titleTextStyle: {color: '#333'}},
            vAxis: {minValue: 0}
        };

        var chart = new google.visualization.AreaChart(document.getElementById('chart_div'));
        chart.draw(data, options);
    }
</script>

<div class="report-cards">
    <div class="report-card">
        <h3>Zag</h3>
        <h2>32</h2>
    </div>
    <div class="report-card">
        <h3>Zag</h3>
        <h2>32</h2>
    </div>
    <div class="report-card">
        <h3>Zag</h3>
        <h2>32</h2>
    </div>
    <div class="report-card">
        <h3>Zag</h3>
        <h2>32</h2>
    </div>
</div>

<div class="charts">
    <div class="chart">
        <div id="chart_div" style="width: 100%; height: 500px;"></div>
    </div>
    <div class="pie-chart">
        <h3>Number of vulnaribilities: <span>6</span></h3>
        <div class="pie-flex">
            <div class="pie animate no-round" style="--p:80;--c:#E53D00;"> <div>80%</div>High</div>
            <div class="pie animate no-round" style="--p:80;--c:#FFC700;"> <div>50%</div>Medium</div>
            <div class="pie animate no-round" style="--p:80;--c:#006BA6;"> <div>20%</div>Low</div>
        </div>
    </div>
</div>