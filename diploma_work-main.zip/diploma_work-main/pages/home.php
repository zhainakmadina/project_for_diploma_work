<div class="dashboard-wp">
    <h1>Welcome to NoneMiracleAudit!</h1>
    <p>We are working hard on creating a free & Open source solution for all of your SEO issues. We will keep on building and improving it. From SEO to NLP and Security. We will add everything.</p>
    <div class="dashboard-buttons">
        <a href="/welcome"><i class="fa-solid fa-house"></i> NoneMiracleAudit</a>
        <a href="#"><i class="fa-brands fa-github"></i> Github</a>
    </div>
</div>

<h1 class="dashboard_url_title">Enter your url:</h1>
<form class="form_url" id="form_url">
    <input name="url" type="text" placeholder="https://www.google.com" required>
    <button><i class="fa-solid fa-chart-simple"></i> Audit site</button>
</form>