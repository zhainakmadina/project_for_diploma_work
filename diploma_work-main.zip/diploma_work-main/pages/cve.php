<?php 

$cve = $_GET['cve'];

$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_URL, 'https://cve.circl.lu/api/cve/'.$cve);
$response = curl_exec($ch);
curl_close($ch);

$object = json_decode($response);

?>

<div class="container-table">
    <div class="table">
        <table>
            <tbody class="cve">
                <?php foreach($object as $obj => $key) { ?>
                <tr>
                    <td><?php echo $obj ?></td>
                    <td>
                        <div class="table-data">
                            <?php
                                if(gettype($key) == "array") {
                                    foreach($key as $key2) {
                                        if(gettype($key2) == "object") {
                                            foreach($key2 as $key3 => $value3) {
                                                if(!is_array($value3)) {
                                                    echo 
                                                    "<table>
                                                        <tr class='bg'>
                                                            <td>{$key3}</td>
                                                            <td>{$value3}</td>
                                                        </tr>
                                                    </table>";
                                                }
                                            }
                                        }
                                        if(!is_array($key2) && !is_object($key2)) {
                                            echo $key2."<br>";
                                        }
                                    }
                                } elseif(gettype($key) == "object") {
                                    foreach($key as $key2 => $value2) {

                                        if(is_array($value2)) {
                                            foreach($value2 as $arr2 ) {
                                                if(gettype($arr2) == "string") {
                                                    echo $arr2."<br>";
                                                }
                                            }
                                        } else {
                                            echo $key2 .': '.$value2.'<br>';
                                        }
                                        
                                    }
                                } else {
                                    echo $key.'<br>';
                                }
                            ?>
                        </div>
                        <div class="collapse"><i class="fa-solid fa-angle-down"></i></div>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>