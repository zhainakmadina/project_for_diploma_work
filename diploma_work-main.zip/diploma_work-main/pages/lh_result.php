<?php

$id = $_GET['id_url'];
require $_SERVER["DOCUMENT_ROOT"]."/modules/lighthouse/{$id}.html";