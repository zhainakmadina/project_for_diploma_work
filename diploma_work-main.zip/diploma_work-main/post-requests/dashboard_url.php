<?php

require $_SERVER["DOCUMENT_ROOT"].'/database/action.php';
session_start();

$url = $_POST["url"];
$user_id = $_SESSION["user"]["id"];
  
function check_url($url) {
    $headers = @get_headers($url);
    if($headers && strpos( $headers[0], '200')) {
        return true;
    }
    else {
        return false;
    }
}

// lighthouse https://google.com --output-path=C:\Users\moon\Desktop\as\1.html

if(check_url($url)) {
    $path = $_SERVER['DOCUMENT_ROOT'].'/modules/mutation/xsstrike.py';
    $path_cmd = str_replace('/','\\', $path);
    $python_output = shell_exec("python {$path_cmd} -u \"{$url}\"");

    if(preg_match_all("/CVE-\d{4}-\d{0,6}/", $python_output, $matches)) {
        $array_uni = array_unique($matches[0]);
        $cves = json_encode(array_values($array_uni));
        echo $cves;
        $res = Action::add_url($url, $user_id, $cves);


        // Lighthouse
        $lh_path = $_SERVER['DOCUMENT_ROOT']."/modules/lighthouse/{$res}.html";
        shell_exec("lighthouse {$url} --output-path={$lh_path}");

        echo "success";
    } else {
        Action::add_url($url, $user_id);
        echo "none";
    }
} else {
    echo "error";
}