$(document).ready(function() {
    $('.arrow span').click(function() {
        $(this).next().toggleClass('show');
        $(this).children('i').toggleClass('rotate');
    });

    $('.close-msg').click(function() {
        $('.msg').removeClass('show');
        $('.darken').removeClass('show');
    });

    $('.darken').click(function() {
        $('.msg').removeClass('show');
        $(this).removeClass('show');
    });

    $('#form_url').submit(function() {
        $('.loader').addClass("show");

        var th = $(this);
		$.ajax({
			type: "POST",
			url: "/post-requests/dashboard_url.php",
			data: th.serialize()
		}).done(function(data) {
            if(data == "error") {
                $('.darken').addClass("show");
                $('.loader').removeClass("show");
                $('.msg p').text("Error! Check the template link is correct or the link is invalid");
                $('.msg').addClass("show");
            } else {
                window.location.href = "/?page=websites";
            }
		});

		return false;
    });

    $('.cve tr').click(function() {
        $(this).find('.collapse').toggleClass('rotate');
        $(this).find('.table-data').toggleClass('full');
        $(this).toggleClass('bg');
        $('.cve td table tr').addClass('bg');
    });


    $('#content').append($('article'));
    $('.lh-sticky-header').css('width', $('.lh-container').width());
});